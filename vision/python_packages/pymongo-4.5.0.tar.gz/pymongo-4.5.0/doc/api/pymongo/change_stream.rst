:mod:`change_stream` -- Watch changes on a collection, database, or cluster
===========================================================================

.. automodule:: pymongo.change_stream
   :members:
