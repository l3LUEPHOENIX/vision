:mod:`write_concern` -- Tools for specifying write concern
==========================================================

.. automodule:: pymongo.write_concern
   :synopsis: Tools for specifying write concern.
   :members:
