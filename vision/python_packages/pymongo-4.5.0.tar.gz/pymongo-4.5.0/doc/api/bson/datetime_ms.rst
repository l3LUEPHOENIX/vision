:mod:`datetime_ms` -- Support for BSON UTC Datetime
===================================================

.. automodule:: bson.datetime_ms
   :synopsis: Support for BSON UTC datetimes.
   :members:
